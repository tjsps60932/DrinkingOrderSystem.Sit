﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.DTOs
{
	public class CreateOrderRequest
	{
		public int CustomerId { get; set; }

		public List<CreateOrderItem> Items { get; set; }

		public int Total => Items.Sum(x => x.SubTotal);

	}
}