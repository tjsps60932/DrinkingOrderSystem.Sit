﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.DTOs;
using DrinkingOrder.BK.Sit.Models.EFModels;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Entity;

namespace DrinkingOrder.BK.Sit.Models.Infrastructures.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly AppDbContext _db;

        public OrderRepository(AppDbContext db)
        {
            _db = db;
        }

        public int Create(CreateOrderRequest request)
        {
            int[] productIds = request.Items.Select(x=> x.ProductId).ToArray();

            Product[] products = _db.Products.Where(x => productIds.Contains(x.Id)).ToArray();

            var order = new Order
            {
                MemberId = request.CustomerId,
                Total = request.Items.Sum(x => x.SubTotal),
                CreatedTime = DateTime.Now,
                Status = true,
                OrderItems = request.Items.Select(x => x.ToEF()).ToList()
            };

            _db.Orders.Add(order);
            _db.SaveChanges();

            return order.Id;
        }

        public OrderEntity Load(int orderId)
        {
            return _db.Orders
                .AsNoTracking()
                .Include(x => x.OrderItems.Select(x2 => x2.Product))
                .Include(x => x.Id)
                .SingleOrDefault(x => x.Id == orderId)
                .ToEntity();
        }

        /// <summary>
		/// 查詢單一客戶的訂單
		/// </summary>
		/// <param name="customerAccount"></param>
		/// <param name="startTime"></param>
		/// <param name="endTime"></param>
		/// <returns></returns>
		/// <exception cref="NotImplementedException"></exception>
        public IEnumerable<OrderEntity> Search(string customerAccount, DateTime? startTime, DateTime? endTime)
        {
            var query = _db.Orders
                        .AsNoTracking()
                        .Include(x => x.Member)
                        .Include(x => x.OrderItems.Select(x2 => x2.Product))
                        .Where(x => x.Member.Account == customerAccount);

            if (startTime.HasValue) query = query.Where(x => x.CreatedTime >= startTime);
            if (endTime.HasValue) query = query.Where(x => x.CreatedTime <= endTime);

            query = query.OrderByDescending(x => x.Id);

            return query.ToList()
                        .Select(x => x.ToEntity())
                        .ToList();

        }
    }
}