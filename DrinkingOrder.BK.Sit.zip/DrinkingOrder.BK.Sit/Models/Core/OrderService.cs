﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Core
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;
        public event Action<IOrderService, int> OrderCreated;
        public OrderService(IOrderRepository repository)
        {
            _repository = repository;
        }

        public void PlaceOrder(CreateOrderRequest request)
        {
            //修改IOrderRepository.Crate,傳回值由void 改為 int
            int orderId = _repository.Create(request);

            //觸發事件
            OnOrderCreated(orderId);
        }

        protected virtual void OnOrderCreated(int orderId)
        {
            if (OrderCreated != null)
            {
                OrderCreated(this, orderId);
            }
        }


    }
}