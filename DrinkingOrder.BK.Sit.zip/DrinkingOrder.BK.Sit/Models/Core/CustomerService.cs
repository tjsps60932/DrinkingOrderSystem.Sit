﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Core
{
    public class CustomerService 
    {
        private readonly ICustomerRepository _repository;

        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }

        public CustomerEntity Load(string customerAccount)
        =>_repository.IsExists(customerAccount)
            ? Load(customerAccount)
            : throw new Exception("找不到有權限購物的客戶資料"); //三元運算式 return(method) ? 如果是就跑這個 : throw 如果不是就跑

        public int GetCustomerId(string customerAccount)
            => Load(customerAccount).Id;


    }
}