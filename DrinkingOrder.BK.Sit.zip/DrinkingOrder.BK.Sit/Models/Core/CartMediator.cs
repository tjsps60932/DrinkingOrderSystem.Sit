﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.DTOs;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Core
{
    public class CartMediator
    {
        private readonly ICartService _cart;
        private readonly IOrderService _order;
        

        public CartMediator(ICartService cart, IOrderService order)
        {
            _cart = cart;
            _order = order;

            _cart.RequestCheckout += _cart_RequestCheckout; //Checkout觸發
        }

        private void _cart_RequestCheckout(ICartService sender, string customerAccount)
        {
            CartEntity cart = _cart.Current(customerAccount);

            //結帳，建立一個新訂單及明細
            CreateOrderRequest request = _cart.ToCreateOrderRequest(cart);

            _cart.EmptyCart(customerAccount); //清空購物車
        }
    }
}