﻿using DrinkingOrder.BK.Sit.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrinkingOrder.BK.Sit.Models.Core.Interfaces
{
    public interface IOrderService
    {
        /// <summary>
		/// 結帳，建立一個新訂單及明細
		/// </summary>
		/// <param name="request"></param>
		void PlaceOrder(CreateOrderRequest request);


    }
}
