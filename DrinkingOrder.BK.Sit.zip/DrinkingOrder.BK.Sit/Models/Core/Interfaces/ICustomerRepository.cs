﻿using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrinkingOrder.BK.Sit.Models.Core.Interfaces
{
	/// <summary>
	/// 對前台購物網站而言，買家是Customer，與Member的概念不同，所以在此額外寫一個CustomerService / CustomerRepository
	/// </summary>
	public interface ICustomerRepository
	{
		/// <summary>
		/// 有權限在本網站購物的會員才會傳回true
		/// </summary>
		/// <param name="customerAccount"></param>
		/// <returns></returns>
		bool IsExists(string customerAccount);

		/// <summary>
		/// 有權限在本網站購物的會員才會傳回id值
		/// </summary>
		/// <param name="customerAccount"></param>
		/// <returns></returns>
		int GetCustomerId(string customerAccount);

		/// <summary>
		/// 有權限在本網站購物的會員才會傳回物件
		/// </summary>
		/// <param name="customerAccount"></param>
		/// <returns></returns>
		CustomerEntity Load(string customerAccount);
	}
}
