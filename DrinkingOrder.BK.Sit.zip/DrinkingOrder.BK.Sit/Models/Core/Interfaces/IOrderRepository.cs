﻿using DrinkingOrder.BK.Sit.Models.DTOs;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrinkingOrder.BK.Sit.Models.Core.Interfaces
{
    public interface IOrderRepository
    {
		/// <summary>
		/// 結帳時，建立一筆新紀錄及明細
		/// </summary>
		/// <param name="request"></param>
		/// <returns></returns>
		int Create(CreateOrderRequest request);

		/// <summary>
		/// 傳回訂單
		/// </summary>
		/// <param name="order"></param>
		/// <returns></returns>
		OrderEntity Load(int order);

		IEnumerable<OrderEntity> Search(string customerAccount, DateTime? startTime, DateTime? endTime);

	}
}
