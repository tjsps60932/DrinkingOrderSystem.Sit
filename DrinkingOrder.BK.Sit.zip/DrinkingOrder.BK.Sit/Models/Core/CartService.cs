﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.DTOs;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Core
{
    public class CartService : ICartService
    {
        public event Action<ICartService, string> RequestCheckout;

        private readonly ICartRepository _repository;  //建構子16~27
        private readonly IProductRepository _productRepo;
        private readonly ICustomerRepository _customerRepo;

        public CartService(ICartRepository repository,
                            IProductRepository productRepo,
                            ICustomerRepository customerRepo)
        {
            _repository = repository;
            _productRepo = productRepo;
            _customerRepo = customerRepo;
        }

        public void Checkout(string customerAccount)
        {
            if (string.IsNullOrEmpty(customerAccount)) throw new ArgumentNullException(nameof(customerAccount));

            OnRequestCheckout(customerAccount);
        }

        //protected外面不可呼叫
        //virtual未來的子類別可以複寫
        protected virtual void OnRequestCheckout(string customerAccount)
        {
            if (RequestCheckout != null)
            {
                RequestCheckout(this, customerAccount);
            }
        }

        //購物車是否存在，若有則Load提取資料；若無，則新增一個購物車
        public CartEntity Current(string customerAccount)
        {
            if(_repository.IsExists(customerAccount))
            {
                return _repository.Load(customerAccount);
            }
            else
            {
                return _repository.CreateNewCart(customerAccount);
            }
        }


        public void AddItem(string customerAccount, int productId, int qty = 1)
        {
            var cart = Current(customerAccount);

            //購物車中有東西，傳回商品
            var product = _productRepo.Load(productId, true);
            var cartProd = new CartProductEntity { Id=product.Id,Name=product.Name,Price=product.Price};

            //CartEntity的方法
            cart.AddItem(cartProd,qty);
            
            //AddItem只有在這網頁cart變化，要Save才有存到資料庫
            _repository.Save(cart);
        }

        public void EmptyCart(string customerAccount)
        {
            _repository.EmptyCart(customerAccount);
        }

        public void RemoveItem(string customerAccount, int productId)
        {
            var cart = Current(customerAccount);

            //CartEntity的方法
            cart.RemoveItem(productId);

            _repository.Save(cart);
        }

        public CreateOrderRequest ToCreateOrderRequest(CartEntity cart)
        {
            List<CreateOrderItem> items = cart.GetItems()
                                         .Select(x => new CreateOrderItem
                                         {
                                             ProductId = x.Product.Id,
                                             ProductName = x.Product.Name,
                                             Price = x.Product.Price,
                                             Qty = x.Qty
                                         })
                                         .ToList();

            return new CreateOrderRequest
            {
                CustomerId = _customerRepo.GetCustomerId(cart.CustomerAccount),
                Items = items
            };
        }

        public void UpdateItem(string customerAccount, int productId, int newQty)
        {
            var cart = Current(customerAccount);

            //CartEntity的方法
            cart.UpdateQty(productId, newQty);

            _repository.Save(cart);
        }
    }
}