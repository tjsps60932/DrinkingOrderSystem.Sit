﻿using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Core
{
    public class ProductService
    {
        private readonly IProductRepository _repository;

        public ProductService(IProductRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<ProductEntity> SearchActiveProduct(int? storeId, string productName)
        => _repository.Search(storeId, productName, true);

        public ProductEntity LoadActiveProduct(int productId)
            => _repository.Load(productId, true);
        

    }
}