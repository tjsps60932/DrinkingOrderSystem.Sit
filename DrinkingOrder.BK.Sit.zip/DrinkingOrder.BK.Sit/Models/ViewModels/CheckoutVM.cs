﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.ViewModels
{
    public class CheckoutVM
    {
        [Display(Name = "取貨人")]
        [Required]
        [MaxLength(30)]
        public string Receiver { get; set; }

        [Display(Name = "手機")]
        [Required]
        [MaxLength(10)]
        public string CellPhone { get; set; }

    }
}