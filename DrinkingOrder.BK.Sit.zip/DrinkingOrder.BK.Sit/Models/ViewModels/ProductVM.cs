﻿using DrinkingOrder.BK.Sit.Models.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.ViewModels
{
    public class ProductVM
    {
        public int Id { get; set; }

        public int CategoryId { get; set; }


        [Display(Name = "品名")]
        public string Name { get; set; }


        [Display(Name = "分類")]
        public string CategoryName { get; set; }


        [Display(Name = "商品描述")]
        public string Description { get; set; }


        [Display(Name = "售價")]
        public int Price { get; set; }

    }

    public static partial class PorductEntityExts
    {
        public static ProductVM ToVM(this ProductEntity source)
        {
            return new ProductVM
            {
                Id = source.Id,
                Name = source.Name,
                //CategoryName = source.Category.Name,
                Description = source.Description,
                Price = source.Price
            };
        }
    }

}
