﻿using DrinkingOrder.BK.Sit.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Entities
{
	public class OrderEntity
	{
		public OrderEntity(int id, int customerId, List<OrderItemEntity> items, DateTime createdTime)
		{
			Id = id;
			CustomerId = customerId;
			Items = items;
			CreatedTime = createdTime;
		}
		public int Id { get; set; }
		public int CustomerId { get; set; }
		public string CustomerAccount { get; set; }

		private List<OrderItemEntity> _Items;
		public List<OrderItemEntity> Items
		{
			get => _Items;
			set => _Items = (value != null && value.Count > 0) ? value : throw new Exception("Items不能是空的");
		}
		public int Total => Items.Sum(x => x.SubTotal);
		public bool RequestRefund { get; set; }
		public DateTime? RequestRefundTime { get; set; }
		public DateTime CreatedTime { get; set; }

		private bool _Status;
		public bool Status
		{
			get => _Status;
			set => _Status = (value==true) ? value : throw new Exception("Status只能為true");
		}
	}

	public static partial class OrderExts
	{
		public static OrderEntity ToEntity(this Order source)
		{
			if (source == null) return null;

			List<OrderItemEntity> items = source.OrderItems
										.Select(x => x.ToEntity())
										.ToList();

			return new OrderEntity(source.Id,
									source.MemberId,
									items,
									source.CreatedTime
									)
			{
				CustomerAccount = source.Member.Account,
				Status = source.Status
			};
		}
	}

}