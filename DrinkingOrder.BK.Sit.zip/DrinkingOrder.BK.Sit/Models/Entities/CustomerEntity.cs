﻿using DrinkingOrder.BK.Sit.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Entities
{
    public class CustomerEntity
    {
			public int Id { get; set; }

			public string CustomerAccount { get; set; }

	}

	public static class CustomerExts
	{
		public static CustomerEntity ToCustomerEntity(this Member source)
				=> new CustomerEntity { Id = source.Id, CustomerAccount = source.Account };
	}

}