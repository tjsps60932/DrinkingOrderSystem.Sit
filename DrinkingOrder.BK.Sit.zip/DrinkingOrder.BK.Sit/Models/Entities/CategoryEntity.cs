﻿using DrinkingOrder.BK.Sit.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Entities
{
    public class CategoryEntity
    {
		
			public int Id { get; set; }

			public int StoreId { get; set; }

			public string Name { get; set; }

			public int DisplayOrder { get; set; }

			public virtual Store Store { get; set; }

			
	}

	public static partial class CategoryExts
	{
		public static CategoryEntity ToEntity(this Category source)
			=> new CategoryEntity
			{
				Id = source.Id,
				StoreId = source.StoreId,
				Name = source.Name,
				DisplayOrder = source.DisplayOrder,
			};
	}


}