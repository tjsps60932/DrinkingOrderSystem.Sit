﻿using DrinkingOrder.BK.Sit.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Entities
{
	/// <summary>
	/// 這是 Aggregate root
	/// </summary>
	public class CartEntity
	{
		public CartEntity(int id, string customerAccount) //購物車裡沒有就新增一個
		{
			this.Id = id;
			this.CustomerAccount = customerAccount;
			Items = new List<CartItemEntity>();
		}
		public CartEntity(int id, string customerAccount, List<CartItemEntity> items) //購物車裡已經有items
		{
			this.Id = id;
			this.CustomerAccount = customerAccount;
			Items = items;
		}
		public int Id { get; set; }

		private string _CustomerAccount;
		public string CustomerAccount //判斷Customer是否有被停權
		{
			get => _CustomerAccount;
			set => _CustomerAccount = string.IsNullOrEmpty(value) == false
				? value
				: throw new Exception("CustomerAccount不能是空值");
		}
		private List<CartItemEntity> Items;
		public int Total => Items == null || Items.Count == 0 ? 0 : Items.Sum(x => x.SubTotal);
		public bool AllowCheckout => Items != null && Items.Count > 0;

		public void AddItem(CartProductEntity product, int qty)
		{
			if (product == null) throw new ArgumentNullException(nameof(product));
			if (qty <= 0) throw new ArgumentOutOfRangeException(nameof(qty));

			var item = Items.SingleOrDefault(x => x.Product.Id == product.Id);
			if (item == null) //購物車裡沒有item就新增一個
			{
				var carItem = new CartItemEntity(product, qty);
				this.Items.Add(carItem);
			}
			else //購物車裡item有就加一
			{
				item.Qty += qty;
			}
		}
		public void RemoveItem(int productId)
		{
			var item = Items.SingleOrDefault(x => x.Product.Id == productId);
			if (item == null) return; //如果找不到就算了

			Items.Remove(item);
		}
		public void UpdateQty(int productId, int newQty) //直接指定新的數量
		{
			if (newQty <= 0) //newQty <= 0視為要刪除
			{
				RemoveItem(productId);
				return;
			}
			var item = Items.SingleOrDefault(x => x.Product.Id == productId);
			if (item == null) return; //如果找不到就算了

			item.Qty = newQty; //=指定新的數量
		}

		//cart.Items=null(不希望變null)所以寫成cart.GetItem()給他一份要怎麼改都可以;
		public IEnumerable<CartItemEntity> GetItems() 
			=> this.Items;
	}

	public static class CartExts
	{
		public static CartEntity ToEntity(this Cart source)
		{
			var items = source.CartItems.Select(x => x.ToEntity()).ToList();
			return new CartEntity(source.Id, source.MemberAccount, items);
		}

		public static Cart ToEF(this CartEntity source)
		{
			var items = source.GetItems().Select(x => x.ToEF(source.Id)).ToList();

			return new Cart { Id = source.Id, MemberAccount = source.CustomerAccount, CartItems = items };
		}
	}

}