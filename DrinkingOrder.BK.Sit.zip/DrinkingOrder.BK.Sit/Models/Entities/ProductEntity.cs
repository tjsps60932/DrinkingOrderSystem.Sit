﻿using DrinkingOrder.BK.Sit.Models.EFModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DrinkingOrder.BK.Sit.Models.Entities
{
    public class ProductEntity
    {
        
            public int Id { get; set; }

            public int StoreId { get; set; }

            public string Name { get; set; }

            public string Description { get; set; }

            public int Price { get; set; }

            public bool Status { get; set; }
            public CategoryEntity Category { get; set; }


    }

    public static partial class ProductExts
    {
        public static ProductEntity ToEntity(this Product source)
            => new ProductEntity
            {
                Id = source.Id,
                Name = source.Name,
                Description = source.Description,
                Price = source.Price,
                Status = source.Status,
            };
    }


}