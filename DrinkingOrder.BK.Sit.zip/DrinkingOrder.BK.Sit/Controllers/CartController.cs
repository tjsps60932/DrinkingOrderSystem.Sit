﻿using DrinkingOrder.BK.Sit.Models.Core;
using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.EFModels;
using DrinkingOrder.BK.Sit.Models.Infrastructures.Repositories;
using DrinkingOrder.BK.Sit.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DrinkingOrder.BK.Sit.Controllers
{
    public class CartController : Controller
    {
        private ICartService cartService;
        private IOrderService orderService;

        public CartController()
        {
            AppDbContext db = new AppDbContext();
            ICartRepository cartRepo = new CartRepository(db); // Repository實作IRepository
            IProductRepository productRepo = new ProductRepository(db);
            ICustomerRepository customerRepo = new CustomerRepository(db); 

            this.cartService = new CartService(cartRepo, productRepo, customerRepo);
            this.orderService = new OrderService(new OrderRepository(db));
            
        }

        private string CustomerAccount => User.Identity.Name;

        //[Authorize]
        // GET: Cart/AddItem
        public ActionResult AddItem(int productId)
        {
            cartService.AddItem(CustomerAccount, productId, 1);
            return new EmptyResult();
        }

        public ActionResult Info()
        {
            var cart = cartService.Current(CustomerAccount);
            return View(cart);
        }

        public ActionResult UpdateItem(int productId, int Qty)
        {
            Qty = Qty <= 0 ? 0 : Qty;
            cartService.UpdateItem(CustomerAccount, productId, Qty);

            return new EmptyResult();
        }

        public ActionResult Checkout()
        {
            var cart = cartService.Current(CustomerAccount);
            if (cart.AllowCheckout == false)
            {
                ViewBag.ErrorMessage = "購物車是空的，無法進行結帳";
            }
            return View();
        }

        [HttpPost]
        public ActionResult Checkout(CheckoutVM model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var cart = cartService.Current(this.CustomerAccount);
            if (cart.AllowCheckout == false)
            {
                ModelState.AddModelError(string.Empty, "購物車是空的,無法進行結帳");
                return View(model);
            }

            var mediator = new CartMediator(this.cartService, orderService);

            cartService.Checkout(this.CustomerAccount);
            return View("CheckoutConfirm");
        }

    }
}