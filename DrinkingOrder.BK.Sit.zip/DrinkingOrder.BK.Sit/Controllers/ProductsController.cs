﻿using DrinkingOrder.BK.Sit.Models.Core;
using DrinkingOrder.BK.Sit.Models.Core.Interfaces;
using DrinkingOrder.BK.Sit.Models.EFModels;
using DrinkingOrder.BK.Sit.Models.Infrastructures.Repositories;
using DrinkingOrder.BK.Sit.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DrinkingOrder.BK.Sit.Controllers
{
    public class ProductsController : Controller
    {
        private ProductService productService;

        public ProductsController()
        {
            var db = new AppDbContext();

            //ProductRepository要實作IProductRepository
            IProductRepository repo = new ProductRepository(db); 
            this.productService = new ProductService(repo);
        }


        // GET: Products
        public ActionResult Index()
        {
            var data = productService.SearchActiveProduct(null, null)
                        .Select(x => x.ToVM());

            return View(data);
        }


    }
}